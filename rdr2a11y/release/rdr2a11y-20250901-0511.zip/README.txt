Copy both files to your Red Dead Redemption 2 game directory (where RDR2.exe is):
- NativeTrainer.asi
- tolk.dll (optional, needed for NVDA/JAWS speech via Tolk)
- tped.wav / tvehicle.wav / tprop.wav (optional target beeps; place next to NativeTrainer.asi)
Ensure ScriptHookRDR2 is installed. NVDA should be running for speech.
